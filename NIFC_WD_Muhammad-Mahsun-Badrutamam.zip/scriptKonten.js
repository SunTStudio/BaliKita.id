function hari1() {
  let hari1 = document.getElementById("hari1");
  let hari2 = document.getElementById("hari2");
  let hari3 = document.getElementById("hari3");
  let kontenTour = document.getElementById("kontenTour");
  hari1.setAttribute("class", "fw-medium activeTour");
  hari2.setAttribute("class", "fw-medium");
  hari3.setAttribute("class", "fw-medium");
  kontenTour.innerHTML =
    '<p><i class="fa-solid fa-route"></i> 09:00-16:00 Penjemputan Bandara Bali (menyesuaikan dengan jam pesawat)</p><p><i class="fa-solid fa-route"></i> 16:00-20:00 Mengunjungi objek wisata Pantai Pandawa, Melasti, GWK, Uluwatu, dan Pantai Jimbaran</p><p><i class="fa-solid fa-route"></i> 20:00-20:30 Perjalanan Menuju Hotel dikuta ( sesuai pilihan )</p><p><i class="fa-solid fa-route"></i> 20:30-20:25 Free Program</p>';
}

function hari2() {
  let hari1 = document.getElementById("hari1");
  let hari2 = document.getElementById("hari2");
  let hari3 = document.getElementById("hari3");
  let kontenTour = document.getElementById("kontenTour");
  hari1.setAttribute("class", "fw-medium ");
  hari2.setAttribute("class", "fw-medium activeTour");
  hari3.setAttribute("class", "fw-medium");
  kontenTour.innerHTML =
    '<p><i class="fa-solid fa-route"></i> 09:00-09:15 Dijemput di Lobby Hotel</p><p><i class="fa-solid fa-route"></i> 09:15-10:00 Perjalanan menuju objek wisata Air Terjun Blang Singa</p><p><i class="fa-solid fa-route"></i> 10:00-11:00 Menikmati keindahan DTW Air Terjun Blang Singa</p><p><i class="fa-solid fa-route"></i> 11:00-11:15 Menuju kawasan Ubud</p><p><i class="fa-solid fa-route"></i> 11:15-12:15 Mengunjungi objek wisata Puri Taman Saraswati dan Pasar Ubud</p><p><i class="fa-solid fa-route"></i> 12:15-13:00 Mengunjungi Bali Swing dan Sawah Terasering tegalalang</p><p><i class="fa-solid fa-route"></i> 13:00-14:00 Mengunjungi objek wisata kaldera Gunung Batur Kintamani</p><p><i class="fa-solid fa-route"></i> 14:00-15:00 Makan siang di rrestorant lokal ( halal)</p><p><i class="fa-solid fa-route"></i> 15:00-17:00 Mengunjungi objek wisata Desa Penglipuran / Pura Tirta Empul</p><p><i class="fa-solid fa-route"></i> 17:00-18:00 Perjalanan menuju kawasan Sanur</p><p><i class="fa-solid fa-route"></i> 18:00-19:00 Makan malam di kawasan sanur</p><p><i class="fa-solid fa-route"></i> 19:00-19:30 Kembali ke Hotel dan free program</p>';
}

function hari3() {
  let hari1 = document.getElementById("hari1");
  let hari2 = document.getElementById("hari2");
  let hari3 = document.getElementById("hari3");
  let kontenTour = document.getElementById("kontenTour");
  hari1.setAttribute("class", "fw-medium ");
  hari2.setAttribute("class", "fw-medium");
  hari3.setAttribute("class", "fw-medium activeTour");
  kontenTour.innerHTML =
    '<p><i class="fa-solid fa-route"></i> 12:00-12:15 Check Out Hotel ( waktu menyesuaikan dengan tiket pesawat)</p><p><i class="fa-solid fa-route"></i> 12:15-13:15 Shopping oleh-oleh khas Bali Krisna</p><p><i class="fa-solid fa-route"></i> 13:15-14:15 Shopping di Pabrik kata-kata Joger</p><p><i class="fa-solid fa-route"></i> 14:15-15:15 Makan Siang dan diantar ke Bandara</p>';
}
